-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost
-- Thời gian đã tạo: Th4 05, 2024 lúc 08:01 AM
-- Phiên bản máy phục vụ: 10.4.28-MariaDB
-- Phiên bản PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `db_asm2`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Nike'),
(2, 'Adidas');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `title_name` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `contact`
--

INSERT INTO `contact` (`id`, `first_name`, `last_name`, `email`, `phone_number`, `title_name`, `note`) VALUES
(1, 'Duy', 'Duy', 'Duy@gmail.com', '02329743243', '...', '....');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `messenger_messages`
--

CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `available_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `delivered_at` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `date_at` datetime NOT NULL,
  `total` int(11) NOT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `order`
--

INSERT INTO `order` (`id`, `user_id`, `name`, `mobile`, `address`, `date_at`, `total`, `status`) VALUES
(1, 1, 'duy', 98733233, 'go vap', '2019-01-01 00:00:00', 3999, 'Đang xử lý'),
(2, 1, 'duy', 298372, 'go vap', '2024-04-04 00:00:00', 201333, 'Đang xử lý');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `orderid_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `order_detail`
--

INSERT INTO `order_detail` (`id`, `product_id`, `orderid_id`, `quantity`) VALUES
(1, 2, 1, 3),
(2, 2, 2, 1),
(3, 3, 2, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `position`
--

CREATE TABLE `position` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `introduce` varchar(400) DEFAULT NULL,
  `body` varchar(1000) DEFAULT NULL,
  `end` varchar(400) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `product`
--

INSERT INTO `product` (`id`, `category_id`, `title`, `price`, `description`, `image`) VALUES
(1, 1, 'NIKE AIR MAX EXCEE', 290000, '⚡️ KINGSHOES.VN ✓15 Ngày Đổi Hàng ✓Giao Hàng Miễn Phí ✓Thanh Toán Khi Nhận Hàng ✓Bảo Hành Hàng Chính Hãng Trọn Đời.!!!   KINGSHOES.VN \"You\'re King In Your Way\".!!!     KING\'S & QUEEN\'S Check in Tại KINGSHOES.VN  192/2 Nguyễn Thái Bình, phường 12, quận Tâ', 'air-max-dn-shoes-drXjb8-6608e0ebd9e4b.webp'),
(2, 1, 'Air Jordan 1 Low', 1333, 'Inspired by the original that debuted in 1985, the Air Jordan 1 Low offers a clean, classic look that\'s familiar yet always fresh. With an iconic design that pairs perfectly with any \'fit, these kicks ensure you\'ll always be on point.', 'air-jordan-1-low-shoes-6Q1tFM-6608e7982250e.jpg'),
(3, 1, 'Giày Thời Trang Nam Nike Air Max Sc', 200000, 'Đưa phong cách đường phố lên một tầm cao mới với Giày Thời Trang Nam Nike Air Max Sc. Lấy cảm hứng từ những đôi giày chạy huyền thoại, Air Max SC mang đến sự kết hợp hoàn hảo giữa tính thẩm mỹ hợp thời và hiệu năng vượt trội. Đôi giày này không chỉ giúp', 'IMG_1020 (1)-660a33c85ac54.jpg'),
(4, 1, 'Air Force 1 Shadow Pale Ivory', 2233000, 'Fullbox A.i.r Force 1 Shadow Pale Ivory. Phù hợp: Nữ, đi học, đi làm, hoạt động thể thao. Size: 36-39. Chất liệu: Da. Giao hàng toàn quốc. Bảo hành 3 tháng. Đổi trả dễ dàng. Streetwear, trẻ trung năng động.', 'IMG_1013-660a33f15f1c6.jpg'),
(5, 1, 'Air Max 90 Triple White', 22110000, 'Giày thể thao Nam Nữ màu Trắng, Đen. Phong cách trẻ trung năng động gắn liền với dòng giày iconic này. Hàng mới về Full box. Giao hàng toàn quốc. Bảo hành 3 tháng. Đổi trả dễ dàng khi mua Giày Sneakers Air Max 90 Nam Nữ Trắng/Đen Trainers  Rubber Unisex F', '1033641560_originalnye-krossovki-nike-660a3414d3781.jpg'),
(6, 1, 'Air Jordan 4 Retro OG Bred', 123000, 'Giày thể thao Nam Nữ màu Đen. Phong cách streetwear trẻ trung năng động gắn liền với dòng giày iconic này. Hàng mới về Full box. Giao hàng toàn quốc. Bảo hành 3 tháng. Đổi trả dễ dàng khi mua Giày Sneakers Air Jordan 4 Retro OG Bred 2019 Trainers Unisex i', 'W_NIKE_M2K_TEKNO-PLATINUM_TINT_CELERY_WOLF_GREY-1-660a34753dc56.jpg'),
(7, 2, 'Adidas Samba OG “White Blue” Sneakers', 45644000, 'Đưa phong cách đường phố lên một tầm cao mới với Giày Thời Trang Nam Nike Air Max Sc. Lấy cảm hứng từ những đôi giày chạy huyền thoại, Air Max SC mang đến sự kết hợp hoàn hảo giữa tính thẩm mỹ hợp thời và hiệu năng vượt trội. Đôi giày này không chỉ giúp', '7-660a34bb099c9.png'),
(8, 2, 'Adidas Originals Samba OG Low-Top Sneakers', 15200000, 'Giày thể thao Nam Nữ màu Trắng, Đen. Phong cách trẻ trung năng động gắn liền với dòng giày iconic này. Hàng mới về Full box. Giao hàng toàn quốc. Bảo hành 3 tháng. Đổi trả dễ dàng khi mua Giày Sneakers Air Max 90 Nam Nữ Trắng/Đen Trainers  Rubber Unisex F', '5-660a34d4950a8.png'),
(9, 2, 'Adidas Ultraboost 20 “Triple Black” Trainers', 12333333, '⚡️ KINGSHOES.VN ✓15 Ngày Đổi Hàng ✓Giao Hàng Miễn Phí ✓Thanh Toán Khi Nhận Hàng ✓Bảo Hành Hàng Chính Hãng Trọn Đời.!!!   KINGSHOES.VN \"You\'re King In Your Way\".!!!     KING\'S & QUEEN\'S Check in Tại KINGSHOES.VN  192/2 Nguyễn Thái Bình, phường 12, quận Tâ', '5-7-660a34ee5d417.jpg'),
(10, 2, 'Adidas NMD_R1 Low-Top Sneakers', 12333222, 'Giày thể thao Nam Nữ màu Trắng, Đen. Phong cách trẻ trung năng động gắn liền với dòng giày iconic này. Hàng mới về Full box. Giao hàng toàn quốc. Bảo hành 3 tháng. Đổi trả dễ dàng khi mua Giày Sneakers Air Max 90 Nam Nữ Trắng/Đen Trainers  Rubber Unisex F', '5-6-660a350a5f49c.jpg'),
(11, 2, 'Adidas Nmd R1 “Black/Red/White” Trainers', 100000, 'Giày thể thao Nam Nữ màu Đen. Phong cách streetwear trẻ trung năng động gắn liền với dòng giày iconic này. Hàng mới về Full box. Giao hàng toàn quốc. Bảo hành 3 tháng. Đổi trả dễ dàng khi mua Giày Sneakers Air Jordan 4 Retro OG Bred 2019 Trainers Unisex i', '7-6-660a3527c7d52.jpg'),
(12, 2, 'Adidas Women’s White Nmd_r1 Trainers', 900000, 'Inspired by the original that debuted in 1985, the Air Jordan 1 Low offers a clean, classic look that\'s familiar yet always fresh. With an iconic design that pairs perfectly with any \'fit, these kicks ensure you\'ll always be on point.', '16-2-660a35432fd42.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `position_id` int(11) DEFAULT NULL,
  `email` varchar(180) NOT NULL,
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`roles`)),
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`id`, `position_id`, `email`, `roles`, `password`) VALUES
(1, NULL, 'Phung Nhat Duy', '[]', '$2y$13$pQbcxaTSPCjPnb91PpVZRuoc7G9FPj2OkEKuLZa1TGDKjRWhpRAkK'),
(2, NULL, 'admin@gmail.com', '[\"ROLE_USER\",\"ROLE_ADMIN1\",\"ROLE_ADMIN\"]', '$2y$13$BrG2qL.j.wFVFQlRIiMj1.zLaSW6RDt9npUbHlF/ORot5ufRnnY8.');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_BA388B74584665A` (`product_id`),
  ADD KEY `IDX_BA388B7A76ED395` (`user_id`);

--
-- Chỉ mục cho bảng `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `messenger_messages`
--
ALTER TABLE `messenger_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  ADD KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  ADD KEY `IDX_75EA56E016BA31DB` (`delivered_at`);

--
-- Chỉ mục cho bảng `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_F5299398A76ED395` (`user_id`);

--
-- Chỉ mục cho bảng `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_ED896F464584665A` (`product_id`),
  ADD KEY `IDX_ED896F466F90D45B` (`orderid_id`);

--
-- Chỉ mục cho bảng `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_D34A04AD12469DE2` (`category_id`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`),
  ADD KEY `IDX_8D93D649DD842E46` (`position_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `messenger_messages`
--
ALTER TABLE `messenger_messages`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `position`
--
ALTER TABLE `position`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT cho bảng `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `FK_BA388B74584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  ADD CONSTRAINT `FK_BA388B7A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Các ràng buộc cho bảng `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `FK_F5299398A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Các ràng buộc cho bảng `order_detail`
--
ALTER TABLE `order_detail`
  ADD CONSTRAINT `FK_ED896F464584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  ADD CONSTRAINT `FK_ED896F466F90D45B` FOREIGN KEY (`orderid_id`) REFERENCES `order` (`id`);

--
-- Các ràng buộc cho bảng `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `FK_D34A04AD12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`);

--
-- Các ràng buộc cho bảng `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `FK_8D93D649DD842E46` FOREIGN KEY (`position_id`) REFERENCES `position` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
